#include <iostream>

int search01(const char A[], int JmlElemenArray, char Elemen) {
    int flag = -1;

    for (int count = 0; count < JmlElemenArray; count++) {
        if (Elemen == A[count]) {
            flag = count;
            break;
        }
    }
    return flag;
}

int main() {
    using namespace std;

    const int JmlElemenArray = 12;
    const char tika[JmlElemenArray] = {'P', 'R', 'O', 'G', 'R', 'A', 'M', 'M', 'I', 'N', 'G', 'X'};

    cout << "******************************************" << endl;
    cout << "*** S E Q U E N T I A L   S E A R C H  ***" << endl;
    cout << "******************************************" << endl;

    cout << "Data yang ada adalah: " << endl;
    cout << "------------------------------------------" << endl;
    for (int count = 0; count < JmlElemenArray; count++) {
        cout << "\tData [" << count << "] --> " << tika[count] << endl;
    }
    cout << "------------------------------------------" << endl;

    char SearchElemen = 'M';

    cout << "------------------------------------------" << endl;
    cout << "Data yang akan dicari (hardcode): " << SearchElemen << endl;
    cout << "------------------------------------------" << endl;

    int flag = search01(tika, JmlElemenArray, SearchElemen);

    if (flag != -1) {
        cout << "Data '" << SearchElemen << "' ditemukan pada posisi : Data[" << flag << "]" << endl;
    } else {
        cout << "Data '" << SearchElemen << "' yang Anda cari tidak ditemukan" << endl;
    }

    SearchElemen = 'Z';

    cout << endl; // Mengganti \n dengan endl;
    cout << "------------------------------------------" << endl;
    cout << "Mencoba mencari data lain (hardcode): " << SearchElemen << endl;
    cout << "------------------------------------------" << endl;

    flag = search01(tika, JmlElemenArray, SearchElemen);

    if (flag != -1) {
        cout << "Data '" << SearchElemen << "' ditemukan pada posisi : Data[" << flag << "]" << endl;
    } else {
        cout << "Data '" << SearchElemen << "' yang Anda cari tidak ditemukan" << endl;
    }

    return 0;
}