package game;

public class Penyihir extends Karakter implements BisaGunakanSihir {

    public Penyihir(String nama) {
        super(nama, 100);
    }

    @Override
    public void serang() {
        System.out.println("   -> " + this.nama + " menembakkan energi dari tongkat sihirnya!");
    }

    @Override
    public void rapalkanMantra(String mantra) {
        System.out.println("   -> " + this.nama + " merapalkan mantra: '" + mantra + "'!");
    }
}