#include <iostream>
#include <vector>

int search01(const std::vector<int>& A, int SearchElemen) {
    int flag = -1;

    for (int count = 0; count < A.size(); count++) {
        if (SearchElemen == A[count]) {
            flag = count;
            break;
        }
    }
    return flag;
}

int main() {
    using namespace std;

    cout << "******************************************" << endl;
    cout << "*** S E Q U E N T I A L   S E A R C H  ***" << endl;
    cout << "******************************************" << endl;

    int JmlElemenArray;
    cout << "Masukkan jumlah elemen data yang ingin Anda masukkan: ";
    cin >> JmlElemenArray;

    if (JmlElemenArray <= 0) {
        cout << "Jumlah elemen harus lebih dari 0." << endl;
        return 1;
    }

    std::vector<int> tika(JmlElemenArray);

    cout << endl;
    cout << "------------------------------------------" << endl;
    cout << "          Input Data Elemen               " << endl;
    cout << "------------------------------------------" << endl;
    for (int count = 0; count < JmlElemenArray; count++) {
        cout << "Masukkan Data ke-" << (count + 1) << ": ";
        cin >> tika[count];
    }

    cout << endl;
    cout << "------------------------------------------" << endl;
    cout << "           Data yang Dimasukkan           " << endl;
    cout << "------------------------------------------" << endl;
    for (int count = 0; count < JmlElemenArray; count++) {
        cout << "\tData [" << count << "] --> " << tika[count] << endl;
    }
    cout << "------------------------------------------" << endl;

    int SearchElemen;
    cout << "Masukkan data yang akan Anda cari ? : ";
    cin >> SearchElemen;

    cout << endl;
    cout << "------------------------------------------" << endl;
    cout << "           Proses Pencarian               " << endl;
    cout << "------------------------------------------" << endl;

    int flag = search01(tika, SearchElemen);

    if (flag != -1) {
        cout << "Data yang dicari ditemukan pada posisi : Data[" << flag << "]" << endl;
    } else {
        cout << "Data yang Anda cari tidak ditemukan" << endl;
    }

    cin.ignore();
    cin.get();

    return 0;
}