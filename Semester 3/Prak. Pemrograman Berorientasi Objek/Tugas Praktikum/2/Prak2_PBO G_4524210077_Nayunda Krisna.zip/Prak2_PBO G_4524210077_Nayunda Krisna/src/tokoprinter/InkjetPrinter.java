package tokoprinter;

public class InkjetPrinter extends Printer { // <-- extends Printer
    private int jumlahWarna;

    public InkjetPrinter(String nama, float harga, String merk, String tipe, int jumlahWarna) {
        super(nama, harga, merk, tipe); // <-- SUPER
        this.jumlahWarna = jumlahWarna;
    }

    public void showInkDetails() {
        System.out.println("Jumlah Warna Tinta: " + this.jumlahWarna);
    }

    @Override // <-- OVERRIDE
    public void displayPrinterDetails() {
        super.displayPrinterDetails(); // <-- SUPER
        this.showInkDetails();
    }
}