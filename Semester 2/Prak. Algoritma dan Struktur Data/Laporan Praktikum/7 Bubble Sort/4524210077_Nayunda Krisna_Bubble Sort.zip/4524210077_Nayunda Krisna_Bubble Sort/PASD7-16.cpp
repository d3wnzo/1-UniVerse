#include <iostream>
#include <vector>

struct DataElement {
    int value;
};

void displayArray(const std::vector<DataElement>& arr) {
    for (size_t i = 0; i < arr.size(); ++i) {
        std::cout << arr[i].value << " ";
    }
    std::cout << std::endl;
}

int main() {
    int n;

    std::cout << "Masukkan jumlah elemen yang ingin diurutkan: ";
    std::cin >> n;

    if (n <= 0) {
        std::cout << "Jumlah elemen harus positif." << std::endl;
        return 1;
    }

    std::vector<DataElement> A(n);

    std::cout << "Masukkan " << n << " angka:" << std::endl;
    for (int i = 0; i < n; ++i) {
        std::cout << "Elemen ke-" << (i + 1) << ": ";
        std::cin >> A[i].value;
    }

    std::cout << "\nArray Asli: ";
    displayArray(A);

    int k = 0;
    bool swapped_in_pass;

    while (k < n - 1) {
        swapped_in_pass = false;
        for (int i = 0; i < n - 1 - k; ++i) {
            if (A[i].value > A[i+1].value) {
                DataElement temp = A[i];
                A[i] = A[i+1];
                A[i+1] = temp;
                swapped_in_pass = true;
            }
        }
        if (!swapped_in_pass) {
            break;
        }
        k++;
    }

    std::cout << "Array Terurut (Ascending): ";
    displayArray(A);

    return 0;
}