package game;

public interface BisaGunakanSihir {
    void rapalkanMantra(String mantra);
}