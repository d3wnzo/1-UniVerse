package game;

public interface BisaGunakanSenjata {
    void gunakanSenjata();
}