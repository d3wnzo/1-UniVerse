package game;

public abstract class Karakter {
    protected String nama;
    protected int healthPoints;

    public Karakter(String nama, int hp) {
        this.nama = nama;
        this.healthPoints = hp;
    }

    public void terimaSerangan(int damage) {
        this.healthPoints -= damage;
        System.out.println("   -> " + this.nama + " menerima " + damage + " damage! Sisa HP: " + this.healthPoints);
    }

    public abstract void serang();
}