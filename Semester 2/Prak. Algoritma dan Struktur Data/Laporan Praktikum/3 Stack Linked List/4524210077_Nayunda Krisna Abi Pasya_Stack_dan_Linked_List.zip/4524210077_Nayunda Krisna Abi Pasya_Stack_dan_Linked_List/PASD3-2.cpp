#include <iostream>
#include <stdlib.h>     // untuk fungsi malloc
using namespace std;

void BUAT_SIMPUL(int X);
void AWAL();
void CETAK();
void INSERTKANAN();

struct Node {
    int INFO;
    struct Node *LINK;
};

typedef struct Node simpul;

simpul *P, *FIRST, *LAST, *Q;
int X;

int main() {
    int n, nilai;

    FIRST = NULL;

    cout << "Masukkan jumlah data yang ingin dimasukkan: ";
    cin >> n;

    for (int i = 0; i < n; i++) {
        cout << "Masukkan nilai ke-" << i + 1 << ": ";
        cin >> nilai;
        X = nilai;
        BUAT_SIMPUL(X);

        if (FIRST == NULL) {
            AWAL(); // buat simpul awal
        } else {
            INSERTKANAN(); // tambahkan ke kanan
        }
    }

    cout << " Nilai sebelum dilakukan insert kanan: ";
    CETAK();

    cout << " Masukkan nilai baru untuk di-insert di kanan: ";
    cin >> X;
    BUAT_SIMPUL(X);
    INSERTKANAN();

    cout << "  Nilai setelah dilakukan insert kanan: ";
    CETAK();

    return 0;
}

// Fungsi membuat simpul baru
void BUAT_SIMPUL(int X) {
    P = (simpul*) malloc(sizeof(simpul));
    if (P == NULL) {
        cout << "Pembuatan simpul tidak berhasil" << endl;
        exit(1);
    } else {
        P->INFO = X;
        P->LINK = NULL;
    }
}

// Fungsi membuat simpul awal
void AWAL() {
    FIRST = P;
    LAST = P;
    P->LINK = NULL;
}

// Fungsi menginsert simpul di sebelah kanan
void INSERTKANAN() {
    LAST->LINK = P;
    LAST = P;
    P->LINK = NULL;
}

// Fungsi mencetak isi seluruh simpul
void CETAK() {
    Q = FIRST;
    while (Q != NULL) {
        cout << Q->INFO << " ";
        Q = Q->LINK;
    }
    cout << endl;
}