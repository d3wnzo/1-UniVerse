package tokoprinter;

public class Printer extends Product { // <--extends Product
    protected String merk;
    protected String tipe;

    public Printer(String nama, float harga, String merk, String tipe) {
        super(nama, harga); // <-- SUPER
        this.merk = merk;
        this.tipe = tipe;
    }
    
    public void displayPrinterDetails() {
        System.out.println("Merk : " + this.merk);
        System.out.println("Tipe : " + this.tipe);
    }

    @Override // <-- OVERRIDE
    public void displayInfo() {
        super.displayInfo(); // <-- SUPER
        this.displayPrinterDetails();
    }
}