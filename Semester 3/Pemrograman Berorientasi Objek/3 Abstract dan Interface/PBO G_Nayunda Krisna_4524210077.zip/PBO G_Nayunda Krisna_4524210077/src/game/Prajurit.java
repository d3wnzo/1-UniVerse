package game;

public class Prajurit extends Karakter {

    public Prajurit(String nama) {
        super(nama, 150);
    }

    @Override
    public void serang() {
        System.out.println("   -> " + this.nama + " mengayunkan pedangnya dengan gagah!");
    }
}