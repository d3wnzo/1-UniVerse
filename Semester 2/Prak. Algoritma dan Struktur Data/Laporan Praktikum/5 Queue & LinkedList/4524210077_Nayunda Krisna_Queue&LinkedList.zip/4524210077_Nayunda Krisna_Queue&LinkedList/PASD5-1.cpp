#include <iostream>
#include <string>

// Struktur Node untuk menyimpan data OS dan pointer ke node berikutnya
struct Node {
    std::string data;
    Node* next;

    // Konstruktor untuk memudahkan pembuatan Node baru
    Node(std::string val) : data(val), next(nullptr) {}
};

// Fungsi untuk mencetak seluruh isi Linked List
void printList(Node* head) {
    if (head == nullptr) {
        std::cout << "List kosong." << std::endl;
        return;
    }
    Node* current = head;
    while (current != nullptr) {
        std::cout << current->data;
        if (current->next != nullptr) {
            std::cout << " -> ";
        }
        current = current->next;
    }
    std::cout << std::endl;
}

// Fungsi untuk menambahkan node di akhir list (paling bawah)
Node* appendNode(Node* head, std::string newData) {
    Node* newNode = new Node(newData);
    if (head == nullptr) {
        return newNode; // Jika list kosong, node baru adalah head
    }
    Node* current = head;
    while (current->next != nullptr) {
        current = current->next;
    }
    current->next = newNode;
    return head; // Kembalikan head yang mungkin tidak berubah
}

// Fungsi untuk menyisipkan node sebelum node tertentu (di "atas" node target)
Node* insertBefore(Node* head, std::string targetData, std::string newData) {
    Node* newNode = new Node(newData);

    // Kasus 1: List kosong
    if (head == nullptr) {
        std::cout << "Target '" << targetData << "' tidak ditemukan, list kosong." << std::endl;
        return head;
    }

    // Kasus 2: Target adalah head
    if (head->data == targetData) {
        newNode->next = head;
        return newNode; // Node baru menjadi head
    }

    // Kasus 3: Target ada di tengah atau akhir list
    Node* current = head;
    Node* prev = nullptr;
    while (current != nullptr && current->data != targetData) {
        prev = current;
        current = current->next;
    }

    if (current == nullptr) {
        // Target tidak ditemukan
        std::cout << "Target '" << targetData << "' tidak ditemukan dalam list." << std::endl;
        return head;
    } else {
        // Target ditemukan
        prev->next = newNode;
        newNode->next = current;
        std::cout << "'" << newData << "' berhasil ditambahkan sebelum '" << targetData << "'." << std::endl;
        return head;
    }
}

// Fungsi untuk menyisipkan node setelah node tertentu
Node* insertAfter(Node* head, std::string targetData, std::string newData) {
    Node* newNode = new Node(newData);

    if (head == nullptr) {
        std::cout << "Target '" << targetData << "' tidak ditemukan, list kosong." << std::endl;
        return head;
    }

    Node* current = head;
    while (current != nullptr && current->data != targetData) {
        current = current->next;
    }

    if (current == nullptr) {
        // Target tidak ditemukan
        std::cout << "Target '" << targetData << "' tidak ditemukan dalam list." << std::endl;
        return head;
    } else {
        // Target ditemukan
        newNode->next = current->next;
        current->next = newNode;
        std::cout << "'" << newData << "' berhasil ditambahkan setelah '" << targetData << "'." << std::endl;
        return head;
    }
}

int main() {
    // Inisialisasi Linked List sesuai gambar (Original List)
    Node* head = nullptr;
    head = appendNode(head, "Maemo");
    head = appendNode(head, "Symbian");
    head = appendNode(head, "Mac");
    head = appendNode(head, "Windows");
    head = appendNode(head, "iPhone");

    std::cout << "List Awal: ";
    printList(head);
    std::cout << "------------------------------------------" << std::endl;

    // a. Bagaimana cara memasukkan "iPhone 5" diatas "iPhone"
    // (Berarti insert before "iPhone")
    std::cout << "Operasi a: Menambahkan 'iPhone 5' sebelum 'iPhone'" << std::endl;
    head = insertBefore(head, "iPhone", "iPhone 5");
    std::cout << "List Setelah Operasi a: ";
    printList(head);
    std::cout << "------------------------------------------" << std::endl;

    // b. Bagaimana cara menambahkan "Windows Phone" diatas "Windows"
    // (Berarti insert before "Windows")
    std::cout << "Operasi b: Menambahkan 'Windows Phone' sebelum 'Windows'" << std::endl;
    head = insertBefore(head, "Windows", "Windows Phone");
    std::cout << "List Setelah Operasi b: ";
    printList(head);
    std::cout << "------------------------------------------" << std::endl;

    // c. Bagaimana cara menambahkan "SnowLeopard" setelah "Mac"
    std::cout << "Operasi c: Menambahkan 'SnowLeopard' setelah 'Mac'" << std::endl;
    head = insertAfter(head, "Mac", "SnowLeopard");
    std::cout << "List Setelah Operasi c: ";
    printList(head);
    std::cout << "------------------------------------------" << std::endl;

    // d. Bagaimana cara menambahkan "Symbian Belle" setelah "Symbian"
    std::cout << "Operasi d: Menambahkan 'Symbian Belle' setelah 'Symbian'" << std::endl;
    head = insertAfter(head, "Symbian", "Symbian Belle");
    std::cout << "List Setelah Operasi d: ";
    printList(head);
    std::cout << "------------------------------------------" << std::endl;

    // e. Bagaimana cara menambahkan "Maemo 4" yang paling bawah tanpa menghilangkan semuanya
    std::cout << "Operasi e: Menambahkan 'Maemo 4' di akhir list" << std::endl;
    head = appendNode(head, "Maemo 4");
    std::cout << "List Setelah Operasi e: ";
    printList(head);
    std::cout << "------------------------------------------" << std::endl;

    // Membersihkan memori (penting untuk menghindari memory leak)
    Node* current = head;
    while (current != nullptr) {
        Node* nextNode = current->next;
        delete current;
        current = nextNode;
    }
    head = nullptr; // Pastikan head menjadi nullptr setelah semua node dihapus

    return 0;
}