package game;

public class KsatriaNaga extends Karakter implements BisaGunakanSenjata, BisaTerbang {

    public KsatriaNaga(String nama) {
        super(nama, 250);
    }

    @Override
    public void serang() {
        System.out.println("   -> " + this.nama + " menyemburkan api dari mulutnya!");
    }

    @Override
    public void gunakanSenjata() {
        System.out.println("   -> " + this.nama + " menghunus tombak naganya!");
    }

    @Override
    public void terbang() {
        System.out.println("   -> " + this.nama + " mengepakkan sayapnya dan terbang ke angkasa!");
    }
}