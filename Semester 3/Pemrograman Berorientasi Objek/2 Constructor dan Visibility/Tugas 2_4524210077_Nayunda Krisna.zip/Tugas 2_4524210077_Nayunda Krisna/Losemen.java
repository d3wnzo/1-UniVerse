public class Losemen {
    public String namaPenyewa;
    private int nomorKamar;
    private boolean tipeElite;
    private double harga;

    public Losemen(String namaPenyewa, int nomorKamar) {
        this.namaPenyewa = namaPenyewa;
        this.nomorKamar = nomorKamar;
        this.tipeElite = false;
        this.harga = 150000;
    }

    public Losemen(String namaPenyewa, int nomorKamar, boolean tipeElite) {
        this.namaPenyewa = namaPenyewa;
        this.nomorKamar = nomorKamar;
        this.tipeElite = tipeElite;
        this.harga = tipeElite ? 300000 : 150000;
    }

    public void tampilkanStruk(int lamaMenginap) {
        double total = harga * lamaMenginap;
        System.out.println("===== STRUK PENJUALAN LOSEMEN =====");
        System.out.println("Nama Penyewa : " + namaPenyewa);
        System.out.println("Nomor Kamar  : " + nomorKamar);
        System.out.println("Tipe Kamar   : " + (tipeElite ? "Elite" : "Standar"));
        System.out.println("Harga / Malam: Rp " + harga);
        System.out.println("Lama Menginap: " + lamaMenginap + " malam");
        System.out.println("-----------------------------------");
        System.out.println("TOTAL BAYAR  : Rp " + total);
        System.out.println("===================================");
    }
}