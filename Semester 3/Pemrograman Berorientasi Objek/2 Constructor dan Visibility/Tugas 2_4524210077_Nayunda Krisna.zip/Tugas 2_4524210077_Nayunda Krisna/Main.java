import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.println("=== SISTEM PENJUALAN LOSEMEN ===");
        System.out.print("Masukkan nama penyewa : ");
        String nama = input.nextLine();

        System.out.print("Masukkan nomor kamar   : ");
        int nomor = input.nextInt();

        System.out.print("Pilih tipe kamar (1. Standar / 2. Elite) : ");
        int pilihan = input.nextInt();

        System.out.print("Lama menginap (malam) : ");
        int lama = input.nextInt();

        Losemen kamar;
        if (pilihan == 2) {
            kamar = new Losemen(nama, nomor, true);
        } else {
            kamar = new Losemen(nama, nomor);
        }

        kamar.tampilkanStruk(lama);
        input.close();
    }
}