public class AnalisisFibonacci {

    public static void main(String[] args) {
        int n_untuk_waktu = 35;
        int n_untuk_alur = 5;

        System.out.println("--- METODE ITERATIF ---");
        long startIteratif = System.nanoTime();
        long hasilIteratif = fibonacciIteratif(n_untuk_waktu);
        long durasiIteratif = (System.nanoTime() - startIteratif) / 1000;

        System.out.println("Hasil untuk F(" + n_untuk_waktu + "): " + hasilIteratif);
        System.out.println("Waktu Eksekusi: " + durasiIteratif + " mikrodetik");

        lacakAlurIteratif(n_untuk_alur);

        System.out.println("\n\n==========================================================");
        System.out.println("                 VS");
        System.out.println("==========================================================");

        System.out.println("\n--- METODE REKURSIF ---");
        long startRekursif = System.nanoTime();
        long hasilRekursif = fibonacciRekursif(n_untuk_waktu);
        long durasiRekursif = (System.nanoTime() - startRekursif) / 1000;

        System.out.println("Hasil untuk F(" + n_untuk_waktu + "): " + hasilRekursif);
        System.out.println("Waktu Eksekusi: " + durasiRekursif + " mikrodetik");

        lacakAlurRekursif(n_untuk_alur);

        tampilkanAnalisisKompleksitas();
    }

    public static long fibonacciIteratif(int n) {
        if (n <= 1) return n;
        long sukuSebelumnya = 0, sukuSekarang = 1;
        for (int i = 2; i <= n; i++) {
            long sukuBerikutnya = sukuSebelumnya + sukuSekarang;
            sukuSebelumnya = sukuSekarang;
            sukuSekarang = sukuBerikutnya;
        }
        return sukuSekarang;
    }

    public static long fibonacciRekursif(int n) {
        if (n <= 1) return n;
        return fibonacciRekursif(n - 1) + fibonacciRekursif(n - 2);
    }

    public static void lacakAlurIteratif(int n) {
        System.out.println("\n*Alur Kerja Iteratif untuk F(" + n + "):*");
        System.out.println("Proses berjalan lurus langkah demi langkah:");
        if (n <= 1) {
            System.out.println("  - Hasil langsung = " + n);
            return;
        }
        long a = 0, b = 1;
        System.out.println("  - Inisialisasi: F(0) = 0, F(1) = 1");
        for (int i = 2; i <= n; i++) {
            long temp = a + b;
            System.out.println("  - Langkah " + i + ": Hitung " + a + " + " + b + " = " + temp);
            a = b;
            b = temp;
        }
    }

    public static void lacakAlurRekursif(int n) {
        System.out.println("\n*Alur Kerja Rekursif untuk F(" + n + "):*");
        System.out.println("Proses memanggil dirinya sendiri berulang kali:");
        lacakRekursifHelper(n, "  ");
    }

    private static long lacakRekursifHelper(int n, String indent) {
        System.out.println(indent + "-> Panggil F(" + n + ")");
        if (n <= 1) {
            System.out.println(indent + "<- Base Case, hasil F(" + n + ") = " + n);
            return n;
        }
        long hasil = lacakRekursifHelper(n - 1, indent + "  ") + lacakRekursifHelper(n - 2, indent + "  ");
        return hasil;
    }

    public static void tampilkanAnalisisKompleksitas() {
        System.out.println("\n\n==========================================================");
        System.out.println("KESIMPULAN AKHIR");
        System.out.println("==========================================================");
        System.out.println("Iteratif jauh lebih efisien (O(n)) karena prosesnya lurus dan tidak mengulang pekerjaan.");
        System.out.println("Rekursif sangat lambat (O(2^n)) karena banyak perhitungan yang sama diulang di cabang berbeda.");
    }
}