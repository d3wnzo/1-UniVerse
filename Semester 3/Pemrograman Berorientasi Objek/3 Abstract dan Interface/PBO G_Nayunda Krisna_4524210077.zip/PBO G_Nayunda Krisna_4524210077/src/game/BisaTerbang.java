package game;

public interface BisaTerbang {
    void terbang();
}