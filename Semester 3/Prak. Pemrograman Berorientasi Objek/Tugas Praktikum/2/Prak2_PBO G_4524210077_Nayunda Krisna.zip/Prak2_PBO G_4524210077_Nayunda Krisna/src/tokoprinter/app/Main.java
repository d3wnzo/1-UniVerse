package tokoprinter.app;

import tokoprinter.InkjetPrinter;
import tokoprinter.LaserPrinter;

public class Main {
    public static void main(String[] args) {
        System.out.println("===== MEMBUAT OBJEK INKJET PRINTER =====");
        InkjetPrinter printer1 = new InkjetPrinter(
            "Epson L3210", 
            2300000f, 
            "Epson", 
            "Ink Tank", 
            4
        );

        System.out.println("\n--- Memanggil displayInfo() ---");
        printer1.displayInfo();

        System.out.println("\n--- Memanggil displayPrinterDetails() ---");
        printer1.displayPrinterDetails();
        
        System.out.println("\n--- Memanggil showInkDetails() ---");
        printer1.showInkDetails();

        System.out.println("\n========================================\n");

        System.out.println("===== MEMBUAT OBJEK LASER PRINTER =====");
        LaserPrinter printer2 = new LaserPrinter(
            "HP LaserJet M111w", 
            2150000f, 
            "HP", 
            "Monochrome Laser", 
            22
        );
        
        System.out.println("\n--- Memanggil displayInfo() ---");
        printer2.displayInfo();
        
        System.out.println("\n--- Memanggil displayPrinterDetails() ---");
        printer2.displayPrinterDetails();
        
        System.out.println("\n--- Memanggil showLaserDetails() ---");
        printer2.showLaserDetails();
    }
}