#include <iostream>

class BubbleSorter {
private:
    int* data;
    int n;

public:
    BubbleSorter() : data(nullptr), n(0) {
        std::cout << "Objek BubbleSorter dibuat (default)." << std::endl;
    }

    BubbleSorter(int size) {
        if (size > 0) {
            n = size;
            data = new int[n];
            std::cout << "Objek BubbleSorter dibuat dengan ukuran " << n << std::endl;
        } else {
            n = 0;
            data = nullptr;
            std::cout << "Ukuran array tidak valid. Objek BubbleSorter dibuat kosong." << std::endl;
        }
    }

    ~BubbleSorter() {
        if (data != nullptr) {
            delete[] data;
            data = nullptr;
            std::cout << "Memori dibebaskan. Objek BubbleSorter dihancurkan." << std::endl;
        }
    }

    void setSize(int size) {
        if (data != nullptr) {
            delete[] data;
        }
        if (size > 0) {
            n = size;
            data = new int[n];
        } else {
            n = 0;
            data = nullptr;
        }
    }

    void inputData() {
        if (n == 0 || data == nullptr) {
            std::cout << "Array belum diinisialisasi atau ukurannya nol. Set ukuran terlebih dahulu." << std::endl;
            return;
        }
        std::cout << "Masukkan " << n << " data angka:" << std::endl;
        for (int i = 0; i < n; ++i) {
            std::cout << "Data ke-" << (i + 1) << ": ";
            std::cin >> data[i];
        }
    }

    void displayData() {
        if (n == 0 || data == nullptr) {
            std::cout << "Array kosong atau belum diinisialisasi." << std::endl;
            return;
        }
        std::cout << "Data saat ini: ";
        for (int i = 0; i < n; ++i) {
            std::cout << data[i] << " ";
        }
        std::cout << std::endl;
    }

    void tukar(int& a, int& b) {
        int temp = a;
        a = b;
        b = temp;
    }

    void bubbleSortDescending() {
        if (n <= 1 || data == nullptr) {
            std::cout << "Tidak perlu mengurutkan (array kosong atau hanya 1 elemen)." << std::endl;
            return;
        }

        std::cout << "\nProses Bubble Sort (Descending)..." << std::endl;
        bool swapped;

        for (int i = 0; i < n - 1; ++i) {
            swapped = false;
            for (int j = 0; j < n - 1 - i; ++j) {
                if (data[j] < data[j+1]) {
                    tukar(data[j], data[j+1]);
                    swapped = true;
                }
            }
            if (!swapped) {
                break;
            }
        }
        std::cout << "Pengurutan selesai." << std::endl;
    }
};

int main() {
    std::cout << "------------------------------------------" << std::endl;
    std::cout << "Selamat datang di aplikasi Bubble Sort" << std::endl;
    std::cout << "------------------------------------------" << std::endl;

    int jumlah_data;
    std::cout << "Masukkan jumlah data yang ingin diurutkan: ";
    std::cin >> jumlah_data;

    BubbleSorter sorter(jumlah_data);

    std::cout << "\n------------------------------------------" << std::endl;
    std::cout << "           Proses Input Data              " << std::endl;
    std::cout << "------------------------------------------" << std::endl;
    sorter.inputData();

    std::cout << "\n------------------------------------------" << std::endl;
    std::cout << "           Data Awal                      " << std::endl;
    std::cout << "------------------------------------------" << std::endl;
    sorter.displayData();

    std::cout << "\n------------------------------------------" << std::endl;
    std::cout << "           Proses Bubble Sort             " << std::endl;
    std::cout << "------------------------------------------" << std::endl;
    sorter.bubbleSortDescending();

    std::cout << "\n------------------------------------------" << std::endl;
    std::cout << "           Data Setelah Diurutkan         " << std::endl;
    std::cout << "------------------------------------------" << std::endl;
    sorter.displayData();

    std::cout << "\n------------------------------------------" << std::endl;
    std::cout << "               TERIMA KASIH               " << std::endl;
    std::cout << "------------------------------------------" << std::endl;

    return 0;
}