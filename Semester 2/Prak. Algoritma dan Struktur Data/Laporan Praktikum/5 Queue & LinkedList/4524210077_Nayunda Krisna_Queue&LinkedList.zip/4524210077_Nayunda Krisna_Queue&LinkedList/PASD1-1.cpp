#include <iostream>
#include <string>
#include <cstdlib>

using namespace std;

// Struktur Data
struct NilaiMK {
	string npm;
	string nama_mhs;
	float nilai;
};

struct Node {
	NilaiMK info;
	Node* next;
};

struct queue {
	Node* front;
	Node* rear;
};

// Fungsi-fungsi Queue
void buatkosong(queue* Q) {
	Q->front = nullptr;
	Q->rear = nullptr;
}

bool IsKosong(queue Q) {
	return Q.front == nullptr;
}

void add(NilaiMK data, queue* Q) {
	Node* baru = new Node;
	baru->info = data;
	baru->next = nullptr;

	if (IsKosong(*Q)) {
		Q->front = baru;
		Q->rear = baru;
	} else {
		Q->rear->next = baru;
		Q->rear = baru;
	}
}

void del(queue* Q) {
	if (IsKosong(*Q)) {
		cout << "\tAntrian kosong. Tidak bisa menghapus." << endl;
	} else {
		Node* hapus = Q->front;
		cout << "\tData Mahasiswa dengan NPM " << hapus->info.npm << " dihapus." << endl;
		Q->front = Q->front->next;
		delete hapus;

		if (Q->front == nullptr) {
			Q->rear = nullptr;
		}
	}
}

void CetakQueue(queue Q) {
	if (IsKosong(Q)) {
		cout << "\tAntrian kosong." << endl;
	} else {
		Node* bantu = Q.front;
		int nomor = 1;
		while (bantu != nullptr) {
			cout << "\t" << nomor << ". NPM: " << bantu->info.npm
				 << " | Nama: " << bantu->info.nama_mhs
				 << " | Nilai: " << bantu->info.nilai << endl;
			bantu = bantu->next;
			nomor++;
		}
	}
}

int JmlElemen(queue Q) {
	int count = 0;
	Node* bantu = Q.front;
	while (bantu != nullptr) {
		count++;
		bantu = bantu->next;
	}
	return count;
}

// MAIN PROGRAM
int main() {
	queue Q;
	buatkosong(&Q);
	int pilihan;
	NilaiMK infoBaru;

	do {
		#ifdef _WIN32
			system("cls");
		#else
			system("clear");
		#endif

		cout << "==================================" << endl;
		cout << "      PROGRAM ANTRIAN MAHASISWA   " << endl;
		cout << "==================================" << endl;
		cout << "1. Tambah Data Mahasiswa (Enqueue)" << endl;
		cout << "2. Hapus Data Mahasiswa (Dequeue) " << endl;
		cout << "3. Tampilkan Data Mahasiswa       " << endl;
		cout << "4. Cek Antrian Kosong             " << endl;
		cout << "5. Hitung Jumlah Elemen           " << endl;
		cout << "0. Keluar                         " << endl;
		cout << "----------------------------------" << endl;
		cout << "Masukkan Pilihan Anda: ";
		cin >> pilihan;
		cin.ignore();

		switch (pilihan) {
			case 1:
				cout << "\t--- TAMBAH DATA MAHASISWA ---" << endl;
				cout << "Masukkan NPM      : ";
				getline(cin, infoBaru.npm);
				cout << "Masukkan Nama Mhs : ";
				getline(cin, infoBaru.nama_mhs);
				cout << "Masukkan Nilai    : ";
				cin >> infoBaru.nilai;
				cin.ignore();
				add(infoBaru, &Q);
				cout << "\tTekan ENTER untuk melanjutkan...";
				cin.get();
				break;
			case 2:
				cout << "\t--- HAPUS DATA MAHASISWA ---" << endl;
				del(&Q);
				cout << "\tTekan ENTER untuk melanjutkan...";
				cin.get();
				break;
			case 3:
				cout << "\t--- TAMPILKAN DATA MAHASISWA ---" << endl;
				CetakQueue(Q);
				cout << "\tJumlah elemen dalam antrian: " << JmlElemen(Q) << endl;
				cout << "\tTekan ENTER untuk melanjutkan...";
				cin.get();
				break;
			case 4:
				cout << "\t--- CEK ANTRIAN KOSONG ---" << endl;
				if (IsKosong(Q)) {
					cout << "\tAntrian kosong." << endl;
				} else {
					cout << "\tAntrian tidak kosong." << endl;
				}
				cout << "\tTekan ENTER untuk melanjutkan...";
				cin.get();
				break;
			case 5:
				cout << "\t--- HITUNG JUMLAH ELEMEN ---" << endl;
				cout << "\tJumlah elemen dalam antrian: " << JmlElemen(Q) << endl;
				cout << "\tTekan ENTER untuk melanjutkan...";
				cin.get();
				break;
			case 0:
				cout << "\tTerima kasih telah menggunakan program ini. Sampai jumpa!" << endl;
				break;
			default:
				cout << "\tPilihan tidak valid. Silakan coba lagi." << endl;
				cout << "\tTekan ENTER untuk melanjutkan...";
				cin.get();
				break;
		}
	} while (pilihan != 0);

	return 0;
}