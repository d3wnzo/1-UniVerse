package game;

public class Main {
    public static void main(String[] args) {

        System.out.println("=======================");
        System.out.println("--- ABSTRACT CLASS ---");
        System.out.println("=======================");
        System.out.println("KONSEP: Abstract Class adalah 'kerangka dasar' atau 'Ras'.");
        System.out.println("Kita akan membuat karakter 'Prajurit' yang merupakan turunan dari 'Karakter'.\n");

        System.out.println("LANGKAH 1: Membuat objek dari kelas konkret 'Prajurit'.");
        Karakter ksatria = new Prajurit("Aragorn");
        
        System.out.println("\nLANGKAH 2: Memanggil metode 'serang()'.");
        System.out.println("-> Ini adalah metode 'abstract' dari Karakter yang diisi oleh Prajurit.");
        ksatria.serang();

        System.out.println("\nLANGKAH 3: Memanggil metode 'terimaSerangan()'.");
        System.out.println("-> Ini adalah metode 'konkret' yang diwarisi langsung dari Karakter.");
        ksatria.terimaSerangan(30);

        
        System.out.println("\n\n==================");
        System.out.println("--- INTERFACE ---");
        System.out.println("==================");
        System.out.println("KONSEP: Interface adalah 'sertifikasi keahlian' atau 'Job Class'.");
        System.out.println("Kita akan membuat 'Penyihir' yang merupakan 'Karakter' (extends) dan punya keahlian 'BisaGunakanSihir' (implements).\n");

        System.out.println("LANGKAH 1: Membuat objek 'Penyihir'.");
        Penyihir ahliSihir = new Penyihir("Gandalf");

        System.out.println("\nLANGKAH 2: Memanggil metode 'serang()'.");
        System.out.println("-> Metode ini dari abstract class Karakter.");
        ahliSihir.serang();

        System.out.println("\nLANGKAH 3: Memanggil metode 'rapalkanMantra()'.");
        System.out.println("-> Metode ini dari interface 'BisaGunakanSihir'.");
        ahliSihir.rapalkanMantra("You shall not pass!");


        System.out.println("\n\n======================================");
        System.out.println("---  GABUNGAN ABSTRACT & INTERFACE ---");
        System.out.println("======================================");
        System.out.println("KONSEP: Menggabungkan 'Ras' (Abstract) dengan banyak 'Keahlian' (Interface).");
        System.out.println("Kita akan membuat 'KsatriaNaga', dia adalah 'Karakter' (extends) yang bisa 'GunakanSenjata' DAN 'Terbang' (implements).\n");

        System.out.println("LANGKAH 1: Membuat objek 'KsatriaNaga'.");
        KsatriaNaga heroNaga = new KsatriaNaga("Ryu");

        System.out.println("\nLANGKAH 2: Memanggil metode dari Abstract Class Karakter.");
        System.out.println("-> Metode serang() (di-override):");
        heroNaga.serang();
        System.out.println("-> Metode terimaSerangan() (diwarisi):");
        heroNaga.terimaSerangan(50);

        System.out.println("\nLANGKAH 3: Memanggil semua kemampuan dari Interface-nya.");
        System.out.println("-> Dari 'BisaGunakanSenjata':");
        heroNaga.gunakanSenjata();
        System.out.println("-> Dari 'BisaTerbang':");
        heroNaga.terbang();
        
        System.out.println("\n--- SELESAI ---");
    }
}