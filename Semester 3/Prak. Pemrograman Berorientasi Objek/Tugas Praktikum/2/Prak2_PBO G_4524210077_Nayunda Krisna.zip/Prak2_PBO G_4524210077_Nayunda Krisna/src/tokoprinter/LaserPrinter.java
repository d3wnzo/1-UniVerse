package tokoprinter;

public class LaserPrinter extends Printer { // <-- extends 
    private int kecepatanCetak;

    public LaserPrinter(String nama, float harga, String merk, String tipe, int kecepatanCetak) {
        super(nama, harga, merk, tipe); // <-- SUPER
        this.kecepatanCetak = kecepatanCetak;
    }

    public void showLaserDetails() {
        System.out.println("Kecepatan Cetak: " + this.kecepatanCetak + " ppm");
    }

    @Override // <-- HIGHLIGHT ANOTASI INI
    public void displayPrinterDetails() {
        super.displayPrinterDetails(); // <-- SUPER
        this.showLaserDetails();
    }
}